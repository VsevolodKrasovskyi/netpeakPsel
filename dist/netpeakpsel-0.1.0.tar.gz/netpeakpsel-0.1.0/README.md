# NetpeakPsel

# NetpeakPsel
— is a tool for extracting external links from specific sections of web pages such as header, footer, nav and aside.

## Install

You can install the package via `pip`:

